--- AJOUT des rapports en BDD --------

insert into `projectorria`.`report` (`name`, `idReportCategory`, `file`, `sortOrder`, `idle`) 
values 
('reportTermMonthly', '7', 'term.php', '720', '0');
-- -------------------------------------------------------------------------------------------

-- R�cup�ration de l�id du rapport qui sera r�utilis� dans la suite du script
set @idReport = LAST_INSERT_ID();
-- -------------------------------------------------------------------------------------------

-- Table ReportParameter: pour ajouter des parameters au rapport
-- -------------------------------------------------------------------------------------------
INSERT INTO `projectorria`.`reportparameter`
(`idReport`,`name`,`paramType`,`order`,`idle`,`defaultValue`)
VALUES
(@idReport,'idProject','projectList','10',0,'currentProject'),
(@idReport,'month','month','20',0,'currentMonth');


--Definission des droits 
-- Profile Admin
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(1,@idReport,1);

-- Profile Superviseur
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(2,@idReport,1);

-- Profile CdP
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(3,@idReport,0);

-- Profile Equipe
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES(4,@idReport,0);


insert into `projectorria`.`report` (`name`, `idReportCategory`, `file`, `sortOrder`, `idle`) 
values 
('reportTermWeekly', '7', 'term.php', '730', '0');
-- -------------------------------------------------------------------------------------------

-- R�cup�ration de l�id du rapport qui sera r�utilis� dans la suite du script
set @idReport = LAST_INSERT_ID();
-- -------------------------------------------------------------------------------------------

-- Table ReportParameter: pour ajouter des parameters au rapport
-- -------------------------------------------------------------------------------------------
INSERT INTO `projectorria`.`reportparameter`
(`idReport`,`name`,`paramType`,`order`,`idle`,`defaultValue`)
VALUES
(@idReport,'idProject','projectList','10',0,'currentProject'),
(@idReport,'week','week','20',0,'currentWeek');

-- definission des droits
-- Profile Admin
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(1,@idReport,1);

-- Profile Superviseur
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(2,@idReport,1);

-- Profile CdP
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES
(3,@idReport,0);

-- Profile Equipe
INSERT INTO `projectorria`.`habilitationreport`
(`idProfile`,`idReport`,`allowAccess`)
VALUES(4,@idReport,0);

