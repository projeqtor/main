1. Update to the latest Joomla sh404sef version from here: 
	http://download.siliana.com/index.php (you may need to click on test versions depending on how old this doc is)

2. Extract the file zip file, you should have only one file, "com_expose.php"

3. Open your FTP client and upload the "com_expose.php" file to <joomla>/components/com_sh404sef/sef_ext

***ONLY WORKS WITH EXPOSE 4.6.3 or later***
