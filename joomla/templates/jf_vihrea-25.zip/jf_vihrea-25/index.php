<?php
/*------------------------------------------------------------------------
# JF_VIHREA!! - JOOMFREAK.COM JOOMLA 2.5 TEMPLATE 
# March 2013
# ------------------------------------------------------------------------
# COPYRIGHT: (C) 2013 JOOMFREAK.COM / KREATIF MULTIMEDIA GMBH
# LICENSE: Creative Commons Attribution
# AUTHOR: JOOMFREAK.COM
# WEBSITE: http://www.joomfreak.com - http://www.kreatif-multimedia.com
# EMAIL: info@joomfreak.com
-------------------------------------------------------------------------*/

// No direct access.
defined('_JEXEC') or die;

//template_register
function templateRegister(){
	//global $mainframe;
	$app =& JFactory::getApplication();
	$template_dir = JPATH_THEMES.DS.'jf_vihrea';		
	$document = & JFactory::getDocument();
	$register = false;
	$register1 = false;
	if(file_exists($template_dir.DS."/scripts/php/register.ini")){		
		$array = array();
		$handle = @fopen($template_dir.DS.'/scripts/php/register.ini', "r");
		if ($handle) {
			while (($buffer = fgets($handle)) !== false) {
				$tmp = explode('=', $buffer);
				$array[] = $tmp[1];
			}			
			fclose($handle);
			unlink($template_dir.DS.'/scripts/php/register.ini');
		}			
	}
	
	if((!empty($array)) && changeTextUrl($array)){
		$app->redirect('index.php');
	}
}

function changeTextUrl($array){
	jimport('joomla.filesystem.folder');
	jimport('joomla.filesystem.file');
	
	$rand_keys = array_rand($array, 1);
	$textLinkRegister = explode(',', $array[$rand_keys]);	

	$template_dir = JPATH_THEMES.DS.'jf_vihrea';
	$contentIndex = JFile::read($template_dir.DS.'index.php');
	if($contentIndex){
		$contentIndex = str_replace('{url_template_register}', $textLinkRegister[1], $contentIndex);
		$contentIndex = str_replace('{text_template_register}', $textLinkRegister[0], $contentIndex);
		$contentIndex = preg_replace('/\/\/template_register(.*)\/\/end_template_register/s', '', $contentIndex);
		JFile::write($template_dir.DS.'index.php', $contentIndex);
		return true;
	}else{
		return false;
	}
}
templateRegister();
//end_template_register

jimport('joomla.filesystem.file');

JHtml::_('behavior.framework', true);

// get params
$app				= JFactory::getApplication();
$doc				= JFactory::getDocument();
$templateparams		= $app->getTemplate(true)->params;
$menu				= $app->getMenu();
$sitename           = $app->getCfg('sitename');
$latitude           = (float)$this->params->get( 'latitude', '' );
$longitude          = (float)$this->params->get( 'longitude', '' );
$markerdescription  = $this->params->get('markerdescription', '');

$doc->addStyleSheet($this->baseurl.'/templates/system/css/system.css');
$doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/fonts/stylesheet.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/template.css', $type = 'text/css');
$doc->addStyleSheet($this->baseurl.'/templates/'.$this->template.'/css/k2.css', $type = 'text/css');

//$doc->addScript($this->baseurl.'/templates/'.$this->template.'/javascript/md_stylechanger.js', 'text/javascript');
//$doc->addScript($this->baseurl.'/templates/'.$this->template.'/javascript/hide.js', 'text/javascript');

// Logo file or site title param
if ($this->params->get('logoas') == 1 && $this->params->get('logo'))
{
	$logo = '<img src="'. JURI::root() . $this->params->get('logo') .'" alt="'. $sitename .'" />';
}

elseif ($this->params->get('logoas') == 2 && $this->params->get('sitetitle'))
{
	$logo = '<span class="site-title">'. htmlspecialchars($this->params->get('sitetitle')) .'</span>';
}
else
{
	$logo = '<span class="site-title">'. $sitename .'</span>';
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
<head>
<meta name="viewport" content="width=device-width,minimum-scale=1,maximum-scale=1" />
<script src="http:///ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js" type="text/javascript"></script>
<script type="text/javascript">jQuery.noConflict();</script>
<jdoc:include type="head" />

<script type="text/javascript" src="<?php echo $this->baseurl.'/templates/'.$this->template.'/scripts/js/md_stylechanger.js' ?>"></script>
<script type="text/javascript" src="<?php echo $this->baseurl.'/templates/'.$this->template.'/scripts/js/jquery.isotope.min.js' ?>"></script>
<script type="text/javascript">
jQuery(document).ready(function() {
	jQuery.noConflict();
	callIsotope();
	jQuery('#navcollapse').click(function(){
		jQuery('#mainmenu ul.menu').slideToggle("slow");;
	});
	jQuery('#backtotop').click(function() {
		jQuery('body,html').animate({scrollTop:0},800);
	});
})
</script>

<?php if (JRequest::getVar('option') == 'com_contact' && $this->params->get('map')) : ?>
<script src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDqEFJTjKx6L-RpoT-nPiqTi1KJVJimH3I&sensor=false"></script>

<script>
	var map;
	var myCenter=new google.maps.LatLng('<?php echo $latitude ?>', '<?php echo $longitude ?>');
	
	function initialize()
	{
		var mapProp = {
			center:myCenter,
			zoom:13,
			mapTypeId:google.maps.MapTypeId.ROADMAP
		};
	
		map = new google.maps.Map(document.getElementById("googleMap"),mapProp);
	  
		var marker=new google.maps.Marker({
			position:myCenter
		});
	
		<?php if ($this->params->get('marker')) : ?>
		marker.setMap(map);
		<?php endif; ?>
	
		var infowindow = new google.maps.InfoWindow({
			content:'<?php echo $markerdescription; ?>'
		});
	
		infowindow.open(map,marker);
	}

	google.maps.event.addDomListener(window, 'load', initialize);
</script>
<?php endif; ?>

<!--[if IE 7]>
<link href="<?php echo $this->baseurl ?>/templates/<?php echo $this->template; ?>/css/ie7only.css" rel="stylesheet" type="text/css" />
<![endif]-->

</head>

<body>
<div id="wrapper">
	<div id="header" class="wrap">
    	<div class="main"><div class="main-inner clear">
        	<h1 id="logo">
            	<a href="<?php JURI::base(true) ?>" title="<?php echo $sitename; ?>">
            	<?php echo $logo; ?>
                </a>
            </h1>
            <?php if (($this->params->get('social') && ($templateparams->get('facebookicon') || $templateparams->get('twittericon') || $templateparams->get('rssicon'))) || $this->countModules('social')) : ?>
            <div id="social-button">
            	<ul>
                	<?php if ($templateparams->get('facebookicon') && $templateparams->get('facebooklink') != '') : ?>
                    <li><a class="button-facebook" href="<?php echo $templateparams->get('facebooklink'); ?>" target="_blank"></a></li>
                    <?php endif; ?>
                    <?php if ($templateparams->get('twittericon') && $templateparams->get('twitterlink') != '') : ?>
                    <li><a class="button-twitter" href="<?php echo $templateparams->get('twitterlink'); ?>" target="_blank"></a></li>
                    <?php endif; ?>
                    <?php if ($templateparams->get('rssicon') && $templateparams->get('rsslink') != '') : ?>
                    <li><a class="button-rss" href="<?php echo $templateparams->get('rsslink'); ?>" target="_blank"></a></li>
                    <?php endif; ?>
                </ul>
                <jdoc:include type="modules" name="social" style="xhtml" />
            </div>
            <?php endif; ?>
            <div class="clr"></div>
        </div></div>
    </div>
   	<div id="mainmenu" class="wrap">
    	<div class="main"><div class="main-inner clear">
        	<div id="navbutton">
            	<a id="navcollapse">Menu</a>
            </div>
        	<jdoc:include type="modules" name="mainmenu" />
            <?php if ($this->countModules('fontresize') || $this->params->get('fontresizer')) : ?>
            <div class="pull-right">
            <?php if ($templateparams->get('fontresizer')) : ?>
            	<div id="fontsize"></div>
            <?php endif; ?>
            <?php if ($this->countModules('fontresize')) : ?>
            	<jdoc:include type="modules" name="fontresize" style="xhtml" />
            <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="clr"></div>
        </div></div>
    </div>
    <div id="container" class="wrap">
    	<div class="main"><div class="main-inner clear">
        <jdoc:include type="message" />
        <?php if(JRequest::getVar('option') != 'com_contact') : ?>
        	<jdoc:include type="component" />
        <?php endif; ?>
        <?php if(JRequest::getVar('option') == 'com_contact') : ?>
        <div id="isotope">
        	<div id="form-contact" class="<?php echo $this->params->get('map') ? 'width4' : 'width10'; ?>">
            	<div class="contactInner">
            		<jdoc:include type="component" />
        		</div>
            </div>
            <?php if ($this->params->get('map')) : ?>
                <div id="map" class="width6">
                    <div id="googleMap" style="height: 526px;">
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="clr"></div>
        </div></div>
    </div>
    <div id="bottom" class="wrap">
    	<div class="main"><div class="main-inner clear">
        	<jdoc:include type="modules" name="bottom" style="jfcustom" />
            <div class="clr"></div>
        </div></div>
    </div>
    <div id="footer" class="wrap">
    	<div class="main"><div class="main-inner clear">
        	<div id="copyright">
        		<jdoc:include type="modules" name="copyright" />
                <ul class="menu">
                    <li><a title="joomfreak" target="_blank" href="http://www.joomfreak.com">joomfreak.com</a></li>
                    <li class="last"><a title="{text_template_register}" target="_blank" href="{url_template_register}">{text_template_register}</a></li>
                </ul>
            </div>
            <div id="backtotop"></div>
            <div class="clr"></div>
        </div></div>
    </div>
</div>
<jdoc:include type="modules" name="debug" />
</body>
</html>
